-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 07, 2024 at 09:09 AM
-- Server version: 10.4.20-MariaDB
-- PHP Version: 7.4.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `csdept`
--

-- --------------------------------------------------------

--
-- Table structure for table `attendance`
--

CREATE TABLE `attendance` (
  `student_id` int(11) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `status` varchar(10) NOT NULL DEFAULT 'absent',
  `subject` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `attendance`
--

INSERT INTO `attendance` (`student_id`, `date`, `status`, `subject`) VALUES
(1, '2024-01-24', '1', 'EN8010'),
(3, '2024-01-24', '1', 'EN8010'),
(5, '2024-01-24', '1', 'EN8010'),
(6, '2024-01-24', '1', 'EN8010'),
(1, '2024-01-24', '1', 'CS8060'),
(5, '2024-01-24', '1', 'CS8060'),
(1, '2024-01-24', '1', 'PY6035'),
(3, '2024-01-24', '1', 'PY6035'),
(5, '2024-01-24', '1', 'PY6035'),
(6, '2024-01-24', '1', 'PY6035'),
(4, '2024-01-24', '1', 'PY6035'),
(5, '2024-01-25', 'present', 'EN8010');

-- --------------------------------------------------------

--
-- Table structure for table `attendances`
--

CREATE TABLE `attendances` (
  `id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `subject_id` int(11) NOT NULL,
  `attendance_date` date NOT NULL,
  `marked` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `c`
--

CREATE TABLE `c` (
  `studentname` varchar(20) DEFAULT NULL,
  `id` int(10) NOT NULL,
  `cu1` int(10) NOT NULL,
  `cu2` int(10) NOT NULL,
  `cu3` int(10) NOT NULL,
  `cu4` int(10) NOT NULL,
  `cu5` int(10) NOT NULL,
  `ccia` int(10) NOT NULL,
  `cmodel` int(10) NOT NULL,
  `cuniv` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `c`
--

INSERT INTO `c` (`studentname`, `id`, `cu1`, `cu2`, `cu3`, `cu4`, `cu5`, `ccia`, `cmodel`, `cuniv`) VALUES
('Preetha', 1, 0, 0, 78, 0, 0, 0, 0, 0),
('Krish', 2, 0, 0, 0, 0, 0, 0, 0, 55),
('Keerthana', 3, 77, 55, 0, 56, 0, 0, 0, 0),
('Anish', 4, 0, 0, 0, 0, 79, 0, 89, 0),
('Pragya', 5, 0, 0, 0, 0, 0, 86, 0, 0),
('Bharathi', 6, 0, 0, 0, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `cia`
--

CREATE TABLE `cia` (
  `studentname` varchar(20) NOT NULL,
  `id` int(10) NOT NULL,
  `pythoncia` int(10) NOT NULL,
  `htmlcia` int(10) NOT NULL,
  `csscia` int(10) NOT NULL,
  `jscia` int(10) NOT NULL,
  `sqlcia` int(10) NOT NULL,
  `ccia` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `cia`
--

INSERT INTO `cia` (`studentname`, `id`, `pythoncia`, `htmlcia`, `csscia`, `jscia`, `sqlcia`, `ccia`) VALUES
('Preetha', 1, 0, 0, 0, 0, 0, 0),
('Krish', 2, 0, 0, 0, 88, 80, 0),
('Keerthana', 3, 55, 0, 77, 0, 0, 0),
('Anish', 4, 0, 0, 0, 0, 0, 0),
('Pragya', 5, 0, 0, 0, 0, 0, 86),
('Bharathi', 6, 0, 90, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `course`
--

CREATE TABLE `course` (
  `subjectcode` varchar(10) DEFAULT NULL,
  `subject` varchar(20) DEFAULT NULL,
  `type` varchar(15) DEFAULT NULL,
  `credit` int(10) DEFAULT NULL,
  `year` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `course`
--

INSERT INTO `course` (`subjectcode`, `subject`, `type`, `credit`, `year`) VALUES
('EN8010', 'Technical English', 'Theory', 3, 3),
('PY6035', 'Python', 'Theory', 4, 3),
('CL6085', 'C', 'Theory', 3, 1),
('CS8060', 'CSS', 'Theory', 2, 1),
('HT7050', 'HTML', 'Theory', 2, 1),
('CS7050', 'C', 'Lab', 2, 1),
('PY6075', 'Python', 'Lab', 2, 3),
('JS8050', 'JAVASCRIPT', 'Theory', 3, 1),
('CE6045', 'C++', 'Theory', 4, 2),
('OR6070', 'ORACLE', 'Lab', 2, 1),
('SQ7050', 'MY SQL', 'Theory', 3, 3),
('RB5680', 'Ruby', 'Lab', 4, 2),
('NJ7806', 'Node JS', 'Theory', 3, 2),
('OR1234', 'ORACLE', 'Theory', 3, 1),
('SQ1234', 'SQL', 'Theory', 3, 2),
('SQ5678', 'SQL', 'Lab', 2, 2),
('MY2345', 'MY SQL', 'Lab', 2, 3),
('RJ7090', 'REACT JS', 'Theory', 3, 3);

-- --------------------------------------------------------

--
-- Table structure for table `css`
--

CREATE TABLE `css` (
  `studentname` varchar(20) DEFAULT NULL,
  `id` int(10) NOT NULL,
  `cssu1` int(10) NOT NULL,
  `cssu2` int(10) NOT NULL,
  `cssu3` int(10) NOT NULL,
  `cssu4` int(10) NOT NULL,
  `cssu5` int(10) NOT NULL,
  `csscia` int(10) NOT NULL,
  `cssmodel` int(10) NOT NULL,
  `cssuniv` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `css`
--

INSERT INTO `css` (`studentname`, `id`, `cssu1`, `cssu2`, `cssu3`, `cssu4`, `cssu5`, `csscia`, `cssmodel`, `cssuniv`) VALUES
('Preetha', 1, 0, 0, 70, 0, 0, 0, 0, 0),
('Krish', 2, 0, 0, 0, 0, 80, 0, 0, 0),
('Keerthana', 3, 74, 0, 54, 0, 0, 77, 0, 0),
('Anish', 4, 50, 0, 0, 0, 65, 0, 55, 88),
('Pragya', 5, 0, 0, 0, 0, 0, 0, 0, 0),
('Bharathi', 6, 0, 0, 0, 85, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `dept`
--

CREATE TABLE `dept` (
  `username` varchar(20) DEFAULT NULL,
  `password` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `dept`
--

INSERT INTO `dept` (`username`, `password`) VALUES
('Jagan', 'Jagan@70');

-- --------------------------------------------------------

--
-- Table structure for table `faculty`
--

CREATE TABLE `faculty` (
  `facultyname` varchar(20) NOT NULL,
  `username` varchar(20) DEFAULT NULL,
  `password` varchar(20) DEFAULT NULL,
  `id` int(10) NOT NULL,
  `subject` varchar(20) DEFAULT NULL,
  `alloted_period` int(20) NOT NULL DEFAULT 0,
  `alloted_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `faculty`
--

INSERT INTO `faculty` (`facultyname`, `username`, `password`, `id`, `subject`, `alloted_period`, `alloted_date`) VALUES
('Nithish', 'Nithish', 'Nithish@70', 2, 'Python', 4, '2024-01-09'),
('Preesha', 'Preesha', 'Preesha@70', 3, 'HTML', 2, '2024-01-09'),
('Santhosh', 'Santhosh', 'Santhosh@70', 4, 'JAVASCRIPT', 0, NULL),
('Prathap', 'Prathap', 'Prathap@70', 5, 'Node JS', 0, NULL),
('Keerthi', 'Keerthi', 'Keerthi@70', 6, 'CSS', 0, NULL),
('Shakthi', 'Shakthi', 'Shakthi@70', 7, 'C++', 0, NULL),
('Jai', 'Jai', 'jai@70', 1, 'Technical English', 0, NULL),
('Kalai', 'Kalai', 'Kalai@70', 8, 'REACT JS', 0, NULL),
('Mouli', 'Mouli', 'Mouli@70', 9, 'ORACLE', 0, NULL),
('Manoj', 'Manoj', 'Manoj@70', 10, 'Ruby', 0, NULL),
('Bharath', 'Bharath', 'Bharath@70', 11, 'SQL', 0, NULL),
('Abimanyu', 'Abimanyu', 'Abimanyu@70', 12, ' MY SQL', 0, NULL),
('Akshara', 'Akshara', 'Akshara@70', 13, 'C', 0, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `facultywork`
--

CREATE TABLE `facultywork` (
  `facultyname` varchar(20) NOT NULL,
  `subject` varchar(20) DEFAULT NULL,
  `subjectcode` varchar(10) DEFAULT NULL,
  `year` int(10) DEFAULT NULL,
  `id` int(10) NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `day` varchar(15) NOT NULL,
  `se_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `facultywork`
--

INSERT INTO `facultywork` (`facultyname`, `subject`, `subjectcode`, `year`, `id`, `start_time`, `end_time`, `day`, `se_id`) VALUES
('Santhosh', 'JAVASCRIPT', 'JS8050', 1, 4, '00:00:00', '00:00:00', '', 1),
('Mouli', 'ORACLE', 'OR1234', 1, 9, '00:00:00', '00:00:00', '', 2),
('Akshara', 'C', 'CS7050', 1, 13, '00:00:00', '00:00:00', '', 3),
('Preesha', 'HTML', 'HT7050', 1, 3, '00:00:00', '00:00:00', '', 4),
('Keerthi', 'CSS', 'CS8060', 1, 6, '00:00:00', '00:00:00', '', 5),
('Mouli', 'ORACLE', 'OR6070', 1, 9, '00:00:00', '00:00:00', '', 6),
('Akshara', 'C', 'CL6085', 1, 13, '00:00:00', '00:00:00', '', 7),
('Bharath', 'SQL', 'SQ5678', 2, 11, '00:00:00', '00:00:00', '', 8),
('Bharath', 'SQL', 'SQ1234', 2, 11, '00:00:00', '00:00:00', '', 9),
('Prathap', 'Node JS', 'NJ7806', 2, 5, '00:00:00', '00:00:00', '', 10),
('Manoj', 'Ruby', 'RB5680', 2, 10, '00:00:00', '00:00:00', '', 11),
('Shakthi', 'C++', 'CE6045', 2, 7, '00:00:00', '00:00:00', '', 12),
('nithish', 'Python', 'PY6035', 3, 2, '00:00:00', '00:00:00', '', 13),
('Jai', 'Technical English', 'EN8010', 3, 1, '00:00:00', '00:00:00', '', 14),
('nithish', 'Python', 'PY6075', 3, 2, '00:00:00', '00:00:00', '', 15),
('Kalai', 'REACT JS', 'RJ7090', 3, 8, '00:00:00', '00:00:00', '', 16);

-- --------------------------------------------------------

--
-- Table structure for table `html`
--

CREATE TABLE `html` (
  `studentname` varchar(20) NOT NULL,
  `id` int(10) NOT NULL,
  `htmlu1` int(10) NOT NULL,
  `htmlu2` int(10) NOT NULL,
  `htmlu3` int(10) NOT NULL,
  `htmlu4` int(10) NOT NULL,
  `htmlu5` int(10) NOT NULL,
  `htmlcia` int(10) NOT NULL,
  `htmlmodel` int(10) NOT NULL,
  `htmluniv` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `html`
--

INSERT INTO `html` (`studentname`, `id`, `htmlu1`, `htmlu2`, `htmlu3`, `htmlu4`, `htmlu5`, `htmlcia`, `htmlmodel`, `htmluniv`) VALUES
('Preetha', 1, 0, 0, 0, 0, 0, 0, 0, 0),
('Keerthana', 3, 0, 0, 0, 0, 0, 0, 0, 0),
('Anish', 4, 0, 0, 0, 0, 0, 0, 0, 0),
('Pragya', 5, 70, 0, 0, 0, 0, 0, 0, 0),
('Bharathi', 6, 0, 0, 0, 0, 0, 90, 0, 0),
('Krish', 2, 0, 0, 0, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `js`
--

CREATE TABLE `js` (
  `studentname` varchar(20) DEFAULT NULL,
  `id` int(10) NOT NULL,
  `jsu1` int(10) NOT NULL,
  `jsu2` int(10) NOT NULL,
  `jsu3` int(10) NOT NULL,
  `jsu4` int(10) NOT NULL,
  `jsu5` int(10) NOT NULL,
  `jscia` int(10) NOT NULL,
  `jsmodel` int(10) NOT NULL,
  `jsuniv` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `js`
--

INSERT INTO `js` (`studentname`, `id`, `jsu1`, `jsu2`, `jsu3`, `jsu4`, `jsu5`, `jscia`, `jsmodel`, `jsuniv`) VALUES
('Preetha', 1, 0, 0, 45, 0, 0, 0, 0, 0),
('Krish', 2, 0, 68, 0, 50, 0, 88, 0, 0),
('Keerthana', 3, 0, 0, 0, 0, 55, 0, 0, 0),
('Anish', 4, 50, 0, 0, 0, 0, 0, 0, 0),
('Pragya', 5, 0, 0, 0, 0, 0, 0, 90, 0),
('Bharathi', 6, 0, 0, 0, 0, 0, 0, 0, 95);

-- --------------------------------------------------------

--
-- Table structure for table `lessons`
--

CREATE TABLE `lessons` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `date` date DEFAULT NULL,
  `time` time DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `lessons`
--

INSERT INTO `lessons` (`id`, `title`, `description`, `date`, `time`) VALUES
(1, 'Python baics', 'IF else', '2023-12-28', '09:20:00'),
(2, 'HTML basics', 'Open Tags', '2024-01-03', '10:10:00');

-- --------------------------------------------------------

--
-- Table structure for table `model`
--

CREATE TABLE `model` (
  `studentname` varchar(20) NOT NULL,
  `id` int(10) NOT NULL,
  `pythonmodel` int(10) NOT NULL,
  `htmlmodel` int(10) NOT NULL,
  `cssmodel` int(10) NOT NULL,
  `jsmodel` int(10) NOT NULL,
  `sqlmodel` int(10) NOT NULL,
  `cmodel` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `model`
--

INSERT INTO `model` (`studentname`, `id`, `pythonmodel`, `htmlmodel`, `cssmodel`, `jsmodel`, `sqlmodel`, `cmodel`) VALUES
('Preetha', 1, 0, 0, 0, 0, 0, 0),
('Krish', 2, 0, 0, 0, 0, 0, 0),
('Keerthana', 3, 0, 0, 0, 0, 55, 0),
('Anish', 4, 0, 0, 55, 0, 0, 89),
('Pragya', 5, 0, 0, 0, 90, 0, 0),
('Bharathi', 6, 0, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `mysql`
--

CREATE TABLE `mysql` (
  `studentname` varchar(20) DEFAULT NULL,
  `id` int(10) NOT NULL,
  `sqlu1` int(10) NOT NULL,
  `sqlu2` int(10) NOT NULL,
  `sqlu3` int(10) NOT NULL,
  `sqlu4` int(10) NOT NULL,
  `sqlu5` int(10) NOT NULL,
  `sqlcia` int(10) NOT NULL,
  `sqlmodel` int(10) NOT NULL,
  `sqluniv` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `mysql`
--

INSERT INTO `mysql` (`studentname`, `id`, `sqlu1`, `sqlu2`, `sqlu3`, `sqlu4`, `sqlu5`, `sqlcia`, `sqlmodel`, `sqluniv`) VALUES
('Preetha', 1, 66, 55, 0, 0, 56, 0, 0, 0),
('Krish', 2, 0, 0, 44, 0, 0, 80, 0, 0),
('Keerthana', 3, 0, 0, 0, 0, 0, 0, 55, 0),
('Anish', 4, 0, 44, 0, 0, 0, 0, 0, 0),
('Pragya', 5, 55, 0, 0, 92, 0, 0, 0, 0),
('Bharathi', 6, 0, 0, 0, 0, 0, 0, 0, 87);

-- --------------------------------------------------------

--
-- Table structure for table `pdf_files`
--

CREATE TABLE `pdf_files` (
  `id` int(11) NOT NULL,
  `file_name` varchar(255) NOT NULL,
  `file_type` varchar(50) NOT NULL,
  `file_data` longblob NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `studentname` varchar(20) DEFAULT NULL,
  `attd` int(20) NOT NULL,
  `username` varchar(20) DEFAULT NULL,
  `password` varchar(20) DEFAULT NULL,
  `id` int(10) NOT NULL,
  `date` date DEFAULT NULL,
  `student_phone` bigint(20) NOT NULL,
  `parent_phone` bigint(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `aadhar` varchar(50) NOT NULL,
  `religion` varchar(50) NOT NULL,
  `caste` varchar(50) NOT NULL,
  `perm_address` varchar(220) NOT NULL,
  `temp_address` varchar(220) NOT NULL,
  `dob` date DEFAULT NULL,
  `blood_grp` varchar(20) NOT NULL,
  `father_name` varchar(30) NOT NULL,
  `mother_name` varchar(30) NOT NULL,
  `father_occupation` varchar(20) NOT NULL,
  `mother_occupation` varchar(20) NOT NULL,
  `annual_income` varchar(20) NOT NULL,
  `club_name` varchar(50) NOT NULL,
  `mentor_name` varchar(30) NOT NULL,
  `remarks` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`studentname`, `attd`, `username`, `password`, `id`, `date`, `student_phone`, `parent_phone`, `email`, `aadhar`, `religion`, `caste`, `perm_address`, `temp_address`, `dob`, `blood_grp`, `father_name`, `mother_name`, `father_occupation`, `mother_occupation`, `annual_income`, `club_name`, `mentor_name`, `remarks`) VALUES
('Preetha', 1, 'Preetha', 'Preetha@70', 1, '0000-00-00', 9010856321, 7804856639, 'Preetha123@gmail.com', '488556541720', 'Hindu', 'MBC', '2,seng street, utg,cbe', '2,seng street, utg,cbe', '2000-10-18', 'O-ve', 'Jagan', 'Krithika', 'Business', 'Home maker', 'RS. 3,00,000', 'YRC', 'Navin Ganesh', 'NIL'),
('Krish', 1, 'Krish', 'Krish@70', 2, '2023-12-27', 9825674173, 8023456986, 'Krish2345@gmail.com', '856412304578', 'Hindu', 'FC', '24, radha street, Tatabad, Cbe', '24, radha street, Tatabad, Cbe', '2001-04-23', 'A +ve', 'Janar', 'Deepa', 'Business', 'Software Engineer', 'RS. 4,50,000', 'Music', 'Prisilla', 'NIL'),
('Keerthana', 1, 'Keerthana', 'Keerthana@70', 3, '0000-00-00', 8695674164, 934569890, 'Keerthana2345@gmail.com', '705612304575', 'Hindu', 'BC', '46, Nawasuddin street, Hopes, Cbe', '46, nawasuddin street, Hopes, Cbe', '2000-02-15', 'AB +ve', 'Shiva', 'Kanimozhi', 'Business', 'Home Maker', 'RS. 5,00,000', 'NCC', 'Raj Kumar', ''),
('Anish', 1, 'Anish', 'Anish@70', 4, '2023-12-27', 9443694815, 9443599773, 'Anish2000@gmail.com', '987556541825', 'Hindu', 'MBC', '15, ABC street, NavaIndia, Cbe', '15, ABC street, NavaIndia, Cbe', '2000-12-05', 'A -ve', 'Raja', 'Kowsalya', 'Doctor', 'Teacher', 'RS. 4,00,000', 'Dance', 'Navin Ganesh', ''),
('Pragya', 1, 'Pragya', 'Pragya@70', 5, '0000-00-00', 9825674173, 8023456986, 'Pragya2345@gmail.com', '856412304578', 'Hindu', 'OC', '2, grg street, Hopes, Cbe', '2, grg street, Hopes, Cbe', '2000-07-30', 'A +ve', 'Karthikeyan', 'Kavitha', 'Software Engineer', 'Software Engineer', 'RS. 2,50,000', 'Music', 'Prisilla', ''),
('Bharathi', 1, 'Bharathi', 'Bharathi@70', 6, '2023-12-29', 8870561209, 7895364510, 'Bharathi09@gmail.com', '856412304578', 'Hindu', 'OC', '19, Krishna street, Peelamedu, Cbe', '19, Krishna street, Peelamedu, Cbe', '2000-11-09', 'B +ve', 'Abhi', 'Anu', 'Civil Field Engineer', 'Engineer', 'RS. 3,00,000', 'NSS', 'Raj Kumar', '');

-- --------------------------------------------------------

--
-- Table structure for table `studentmarks`
--

CREATE TABLE `studentmarks` (
  `studentname` varchar(20) NOT NULL,
  `id` int(10) NOT NULL,
  `pythonu1` int(10) NOT NULL,
  `pythonu2` int(10) NOT NULL,
  `pythonu3` int(10) NOT NULL,
  `pythonu4` int(10) NOT NULL,
  `pythonu5` int(10) NOT NULL,
  `pythoncia` int(10) NOT NULL,
  `pythonmodel` int(10) NOT NULL,
  `pythonuniv` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `studentmarks`
--

INSERT INTO `studentmarks` (`studentname`, `id`, `pythonu1`, `pythonu2`, `pythonu3`, `pythonu4`, `pythonu5`, `pythoncia`, `pythonmodel`, `pythonuniv`) VALUES
('Preetha', 1, 85, 0, 0, 0, 0, 0, 0, 0),
('Krish', 2, 0, 0, 0, 0, 0, 0, 0, 0),
('Keerthana', 3, 45, 0, 70, 55, 0, 55, 0, 0),
('Anish', 4, 45, 45, 0, 85, 0, 0, 0, 0),
('Pragya', 5, 0, 0, 0, 0, 80, 0, 0, 0),
('Bharathi', 6, 0, 0, 0, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `unit1`
--

CREATE TABLE `unit1` (
  `studentname` varchar(20) NOT NULL,
  `id` int(10) NOT NULL,
  `pythonu1` int(10) NOT NULL,
  `htmlu1` int(10) NOT NULL,
  `cssu1` int(10) NOT NULL,
  `jsu1` int(10) NOT NULL,
  `sqlu1` int(10) NOT NULL,
  `cu1` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `unit1`
--

INSERT INTO `unit1` (`studentname`, `id`, `pythonu1`, `htmlu1`, `cssu1`, `jsu1`, `sqlu1`, `cu1`) VALUES
('Preetha', 1, 85, 0, 0, 0, 66, 0),
('Krish', 2, 0, 0, 0, 0, 0, 0),
('Keerthana', 3, 90, 0, 74, 0, 0, 77),
('Anish', 4, 45, 0, 50, 50, 0, 0),
('Pragya', 5, 0, 70, 0, 0, 55, 0),
('Bharathi', 6, 0, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `unit2`
--

CREATE TABLE `unit2` (
  `studentname` varchar(20) NOT NULL,
  `id` int(10) NOT NULL,
  `pythonu2` int(10) NOT NULL,
  `htmlu2` int(10) NOT NULL,
  `cssu2` int(10) NOT NULL,
  `jsu2` int(10) NOT NULL,
  `sqlu2` int(10) NOT NULL,
  `cu2` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `unit2`
--

INSERT INTO `unit2` (`studentname`, `id`, `pythonu2`, `htmlu2`, `cssu2`, `jsu2`, `sqlu2`, `cu2`) VALUES
('Preetha', 1, 0, 0, 0, 0, 55, 0),
('Krish', 2, 0, 0, 0, 68, 0, 0),
('Keerthana', 3, 0, 0, 0, 0, 0, 55),
('Anish', 4, 45, 0, 0, 0, 44, 0),
('Pragya', 5, 0, 0, 0, 0, 0, 0),
('Bharathi', 6, 0, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `unit3`
--

CREATE TABLE `unit3` (
  `studentname` varchar(20) NOT NULL,
  `id` int(10) NOT NULL,
  `pythonu3` int(10) NOT NULL,
  `htmlu3` int(10) NOT NULL,
  `cssu3` int(10) NOT NULL,
  `jsu3` int(10) NOT NULL,
  `sqlu3` int(10) NOT NULL,
  `cu3` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `unit3`
--

INSERT INTO `unit3` (`studentname`, `id`, `pythonu3`, `htmlu3`, `cssu3`, `jsu3`, `sqlu3`, `cu3`) VALUES
('Preetha', 1, 0, 0, 70, 45, 0, 78),
('Krish', 2, 0, 0, 0, 0, 44, 0),
('Keerthana', 3, 70, 0, 0, 0, 0, 0),
('Anish', 4, 0, 0, 0, 0, 0, 0),
('Pragya', 5, 0, 0, 0, 0, 0, 0),
('Bharathi', 6, 0, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `unit4`
--

CREATE TABLE `unit4` (
  `studentname` varchar(20) NOT NULL,
  `id` int(10) NOT NULL,
  `pythonu4` int(10) NOT NULL,
  `htmlu4` int(10) NOT NULL,
  `cssu4` int(10) NOT NULL,
  `jsu4` int(10) NOT NULL,
  `sqlu4` int(10) NOT NULL,
  `cu4` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `unit4`
--

INSERT INTO `unit4` (`studentname`, `id`, `pythonu4`, `htmlu4`, `cssu4`, `jsu4`, `sqlu4`, `cu4`) VALUES
('Preetha', 1, 0, 0, 0, 0, 0, 0),
('Krish', 2, 0, 0, 0, 50, 0, 0),
('Keerthana', 3, 55, 0, 0, 0, 0, 56),
('Anish', 4, 85, 0, 0, 0, 0, 0),
('Pragya', 5, 0, 0, 0, 0, 92, 0),
('Bharathi', 6, 0, 0, 85, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `unit5`
--

CREATE TABLE `unit5` (
  `studentname` varchar(20) NOT NULL,
  `id` int(10) NOT NULL,
  `pythonu5` int(10) NOT NULL,
  `htmlu5` int(10) NOT NULL,
  `cssu5` int(10) NOT NULL,
  `jsu5` int(10) NOT NULL,
  `sqlu5` int(10) NOT NULL,
  `cu5` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `unit5`
--

INSERT INTO `unit5` (`studentname`, `id`, `pythonu5`, `htmlu5`, `cssu5`, `jsu5`, `sqlu5`, `cu5`) VALUES
('Preetha', 1, 0, 0, 0, 0, 56, 0),
('Krish', 2, 0, 0, 80, 0, 0, 0),
('Keerthana', 3, 0, 0, 0, 55, 0, 0),
('Anish', 4, 0, 0, 65, 0, 0, 79),
('Pragya', 5, 80, 0, 0, 0, 0, 0),
('Bharathi', 6, 0, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `univ`
--

CREATE TABLE `univ` (
  `studentname` varchar(20) NOT NULL,
  `id` int(10) NOT NULL,
  `pythonuniv` int(10) NOT NULL,
  `htmluniv` int(10) NOT NULL,
  `cssuniv` int(10) NOT NULL,
  `jsuniv` int(10) NOT NULL,
  `sqluniv` int(10) NOT NULL,
  `cuniv` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `univ`
--

INSERT INTO `univ` (`studentname`, `id`, `pythonuniv`, `htmluniv`, `cssuniv`, `jsuniv`, `sqluniv`, `cuniv`) VALUES
('Preetha', 1, 0, 0, 0, 0, 0, 0),
('Krish', 2, 0, 0, 0, 0, 0, 55),
('Keerthana', 3, 0, 0, 0, 0, 0, 0),
('Anish', 4, 0, 0, 88, 0, 0, 0),
('Pragya', 5, 0, 0, 0, 0, 0, 0),
('Bharathi', 6, 0, 0, 0, 95, 87, 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `attendances`
--
ALTER TABLE `attendances`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `attendance_date` (`attendance_date`),
  ADD UNIQUE KEY `subject_id` (`subject_id`);

--
-- Indexes for table `facultywork`
--
ALTER TABLE `facultywork`
  ADD PRIMARY KEY (`se_id`);

--
-- Indexes for table `lessons`
--
ALTER TABLE `lessons`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pdf_files`
--
ALTER TABLE `pdf_files`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `attendances`
--
ALTER TABLE `attendances`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `facultywork`
--
ALTER TABLE `facultywork`
  MODIFY `se_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `lessons`
--
ALTER TABLE `lessons`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `pdf_files`
--
ALTER TABLE `pdf_files`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
